//#define switches (volatile char*) 0x00002010
//#define se7seg (char*) 0x00002000

#define switches_add 0x00002010
#define se7seg_add 0x00002000


int main(void)
{

int * se7seg = (int *) se7seg_add; /* red_leds is a pointer to the LEDRs */
volatile int * switches = (int *) switches_add;

int i;

int suis=1;
//*se_seg=*switchess;
    while(1){

suis=(*switches)&3;
  if(suis==1){
    *se7seg=0x79;
    for(i=0;i<1200000;i++);
    *se7seg=0x24;
    for(i=0;i<1200000;i++);
    *se7seg=0x79;
    for(i=0;i<1200000;i++);
    }else if(suis==2){
    *se7seg=0x24;
    }else{
    *se7seg=0x00;
    }
    for(int i=0;i<10000;i++);


    }

    return 0;
}
