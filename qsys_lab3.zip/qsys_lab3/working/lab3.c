//#define switches (volatile char*) 0x00002010
//#define se7seg (char*) 0x00002000

#define switches 0x00002010
#define se7seg 0x00002000


int main(void)
{

int * se_seg = (int *) se7seg; /* red_leds is a pointer to the LEDRs */
volatile int * switchess = (int *) switches;

//char * se7seg = (char *)0x00002000;

int suis=1;
//*se_seg=*switchess;
    while(1){

suis=*switchess;
  if(suis==1){
    *se_seg=0x79;
    }else if(suis==2){
    *se_seg=0x24;
    }else{
    *se_seg=0x00;
    }
    for(int i=0;i<10000;i++);


    }

    return 0;
}
